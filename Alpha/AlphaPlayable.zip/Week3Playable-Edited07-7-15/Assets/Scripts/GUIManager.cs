﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class GUIManager : MonoBehaviour 
{
	public Slider healthBar;
	public Image Life1, Life2, Life3;
	public Text playerScore;

}

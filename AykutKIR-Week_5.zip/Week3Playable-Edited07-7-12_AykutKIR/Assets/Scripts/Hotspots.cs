﻿using UnityEngine;
using System.Collections;

public class Hotspots : MonoBehaviour {

	public int order;

}
